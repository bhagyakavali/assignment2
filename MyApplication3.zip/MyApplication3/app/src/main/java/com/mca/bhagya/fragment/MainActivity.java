package com.mca.bhagya.fragment;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;


import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Spinner country,state,city;
    TextView txt;
    List clist=new ArrayList();
    List slist=new ArrayList();
    List ctlist=new ArrayList();
    ArrayAdapter adaptersp_country,adaptersp_state,adaptersp_city;
    Object coun,stat,cit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        country=(Spinner)findViewById(R.id.spinner);
        state=(Spinner)findViewById(R.id.spinner2);
        city=(Spinner)findViewById(R.id.spinner3);

        txt=(TextView)findViewById(R.id.textView4);
//country

        clist.clear();
        clist.add("-- Select Country --");
        txt.setText("");
        country.setOnItemSelectedListener(this);
        clist.add("India");
        clist.add("China");
        clist.add("Japan");
        clist.add("USA");


        adaptersp_country = new ArrayAdapter<String>(MainActivity.this, R.layout.support_simple_spinner_dropdown_item, clist);
        adaptersp_country.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        country.setAdapter(adaptersp_country);

//city
        // slist.clear();
        slist.add("-- Select State --");

        state.setOnItemSelectedListener(this);
        adaptersp_state = new ArrayAdapter<String>(MainActivity.this, R.layout.support_simple_spinner_dropdown_item, slist);
        adaptersp_state.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        state.setAdapter(adaptersp_state);

        stat = state.getSelectedItem();
//state
        // ctlist.clear();
        ctlist.add("-- Select City --");

        city.setOnItemSelectedListener(this);
        adaptersp_city = new ArrayAdapter<String>(MainActivity.this, R.layout.support_simple_spinner_dropdown_item, ctlist);
        adaptersp_city.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        city.setAdapter(adaptersp_city);

    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        coun=country.getSelectedItem();

        if(coun==null || coun.equals("-- Select Country --")){
            slist.clear();
            slist.add("-- Select State --");
            ctlist.clear();
            ctlist.add("-- Select City --");
            txt.setText("");
            //   Toast.makeText(MainActivity.this, "Please Select Country..", Toast.LENGTH_SHORT).show();
            return;
        }else {
            slist.clear();
            slist.add("-- Select State --");
            if (coun.equals("India")) {
                slist.add("Karnataka");
                slist.add("Goa");
                slist.add("Delhi");
                slist.add("Punjab");
            } else if (coun.equals("China")) {
                slist.add("Shandong");
                slist.add("hang kong");
                slist.add("Macau");
                slist.add("Jinan");
            } else if (coun.equals("Japan")) {
                slist.add("Aichi");
                slist.add("Akita");
                slist.add("Sendai");
                slist.add("Fukui");
            } else {
                slist.add("California");
                slist.add("Florida");
                slist.add("Texas");
                slist.add("Washington");
            }

        }


        stat = state.getSelectedItem();
        ctlist.clear();
        ctlist.add("-- Select City --");
        if(stat==null || stat.equals("-- Select State --")){
            ctlist.clear();
            ctlist.add("-- Select City --");
            txt.setText("");
            return;
        }else{
            if(stat.equals("Karnataka")){
                ctlist.add("Haveri");
                ctlist.add("gadag");
                ctlist.add("Dharwad");

            }else if(stat.equals("Goa")){
                ctlist.add("Panaji");
                ctlist.add("Calangute");
                ctlist.add("Mapusa");

            }else if(stat.equals("Delhi")){
                ctlist.add("Siri");
                ctlist.add("Shergarh");
            }else if(stat.equals("Punjab")){
                ctlist.add("Amritsar");
                ctlist.add("Mohali");

            }else if(stat.equals("Shandong")){
                ctlist.add("Jinan");
                ctlist.add("zibo");
            }else if(stat.equals("hang kong")){
                ctlist.add("Sha Tin");
                ctlist.add("Tai Po");
            }else if(stat.equals("Macau")){

                ctlist.add("Aomen");
                ctlist.add("Luhuan");
            }else if(stat.equals("Jinan")){
                ctlist.add("Dali");
                ctlist.add("Yuxi");
            }else if(stat.equals("Aichi")){
                ctlist.add("Atsuta");
                ctlist.add("Handa");
            }else if(stat.equals("Akita")){
                ctlist.add("Noshiro");
                ctlist.add("Ōdate");
            }else if(stat.equals("Sendai")){
                ctlist.add("South Sendai");
                ctlist.add("North sendai");
            }else if(stat.equals("Fukui")){
                ctlist.add("Sabae");
                ctlist.add("Takefu");

            }else if(stat.equals("California")){

                ctlist.add("Chichibu");
                ctlist.add("Soka");
            }else if(stat.equals("Florida")){
                ctlist.add("Miami");
                ctlist.add("Orlando");

            }else if(stat.equals("Texas")){

                ctlist.add("Dallas");
                ctlist.add("Austin");
            }else if(stat.equals("Washington")){
                ctlist.add("Seattle");
                ctlist.add("Tacoma");

            }

        }
        cit = city.getSelectedItem();

        if(coun==null && stat==null && cit==null){
            txt.setVisibility(View.INVISIBLE);
        }else{
            txt.setText("You Are Selected : Country="+coun+" State="+stat+" City="+cit);
        }



    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}